/*navbar*/
window.addEventListener('scroll', function () {
  const navbar = document.getElementById('navbar');
  if (window.scrollY > 50) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
});

/*Recherche*/
document.getElementById('search-button').addEventListener('click', () => {
  const query = document.getElementById('search-input').value;
  const sortBy = document.getElementById('sort-by').value;
  const releaseDateStart = document.getElementById('release-date-start').value;
  const releaseDateEnd = document.getElementById('release-date-end').value;
  const genre = document.getElementById('genre').value;
  const ageRating = document.getElementById('age-rating').value;
  const userRating = document.getElementById('user-rating').value;
  const voteCount = document.getElementById('vote-count').value;
  const runtime = document.getElementById('runtime').value;
  const keywords = document.getElementById('keywords').value;

  searchMovies(query, sortBy, releaseDateStart, releaseDateEnd, genre, ageRating, userRating, voteCount, runtime, keywords);
});

async function searchMovies(query, sortBy, releaseDateStart, releaseDateEnd, genre, ageRating, userRating, voteCount, runtime, keywords) {
  const apiKey = 'YOUR_TMDB_API_KEY';
  let url = `https://api.themoviedb.org/3/search/movie?api_key=${apiKey}&query=${query}&sort_by=${sortBy}`;

  if (releaseDateStart) {
    url += `&primary_release_date.gte=${releaseDateStart}`;
  }
  if (releaseDateEnd) {
    url += `&primary_release_date.lte=${releaseDateEnd}`;
  }
  if (genre) {
    url += `&with_genres=${genre}`;
  }
  if (ageRating) {
    url += `&certification_country=US&certification=${ageRating}`;
  }
  if (userRating) {
    url += `&vote_average.gte=${userRating}`;
  }
  if (voteCount) {
    url += `&vote_count.gte=${voteCount}`;
  }
  if (runtime) {
    url += `&with_runtime.lte=${runtime}`;
  }
  if (keywords) {
    url += `&with_keywords=${keywords}`;
  }

  const response = await fetch(url);
  const data = await response.json();
  displayResults(data.results);
}

function displayResults(movies) {
  const resultsContainer = document.getElementById('results');
  resultsContainer.innerHTML = '';
  const carousel = document.getElementById('carousel');
  carousel.innerHTML = '';

  movies.forEach(movie => {
    const movieElement = document.createElement('div');
    movieElement.className = 'movie';
    movieElement.innerHTML = `
                    <img src="https://image.tmdb.org/t/p/w200${movie.poster_path}" alt="${movie.title}">
                    <h3>${movie.title}</h3>
                    <p>Sortie : ${movie.release_date}</p>
                    <p>Note : ${movie.vote_average}</p>
                    <button onclick="viewDetails(${movie.id})">Détails</button>
                `;
    resultsContainer.appendChild(movieElement);

    const carouselItem = movieElement.cloneNode(true);
    carousel.appendChild(carouselItem);
  });
}

function viewDetails(movieId) {
  // Redirection vers la page de détails du film
  window.location.href = `details.html?movieId=${movieId}`;
}

/*caroussel*/
(function () {
  var $grid = $(".grid").imagesLoaded(function () {
    $(".site__wrapper").masonry({
      itemSelector: ".grid"
    });
  });
})();
/*-----range slider-------*/
const employees = document.querySelector("#employees")
var labels = { 0: '0', 10: '10', 15: '15', 20: '20', 25: '25', 40: '40', 55: '55', 70: '70', 85: '85', 100: '100', 110: '100+', };
noUiSlider.create(employees, {
  start: 10,
  connect: [true, false],
  tooltips: {
    to: function (value) {
      return value > 100 ? '100+' : parseInt(value)
    }
  },
  range: {
    'min': 0,
    '10%': 10,
    '20%': 15,
    '30%': 20,
    '40%': 25,
    '50%': 40,
    '60%': 55,
    '70%': 70,
    '80%': 85,
    '90%': 100,
    'max': 110
  },
  pips: {
    mode: 'steps',
    filter: function (value, type) {
      return type === 0 ? -1 : 1;
    },
    format: {
      to: function (value) {
        return labels[value];
      }
    }
  }
});

document.getElementById('runtime').addEventListener('change', function () {
  let selectedValue = parseInt(this.value); // Convert selected value to integer
  console.log('Selected duration:', selectedValue);
});