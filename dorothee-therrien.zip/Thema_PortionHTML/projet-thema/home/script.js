/*---------caroussel movie--------*/
$(".custom-carousel").owlCarousel({
  autoWidth: true,
  loop: true
});
$(document).ready(function () {
  $(".custom-carousel .item").click(function () {
    $(".custom-carousel .item").not($(this)).removeClass("active");
    $(this).toggleClass("active");
  });
});

/*----------year-----------*/
let year = document.querySelector("#year");
$(document).ready(function () {
  year.innerText = new Date().getFullYear();
});

/*--------navbar----------*/
window.addEventListener('scroll', function () {
  const navbar = document.getElementById('navbar');
  if (window.scrollY > 50) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
});

/*---Read more-----*/
$(document).ready(function () {
  $('.read-more-link').click(function (e) {
    e.preventDefault();
    $('.additional-text').slideToggle();
    $(this).text(function (i, text) {
      return text === "Read less" ? "Read more ..." : "Read less";
    });
  });
});

/*-----caroussel actors--------*/
const carousel = document.getElementById('carousel');
const willLeftLessThan40pxToScrollEnd = (nextStep) => {
  const scrollLeftAfterTwoClicks = carousel.scrollLeft + (nextStep * 2);
  return scrollLeftAfterTwoClicks > carousel.scrollWidth - 40;
}
const willLeftLessThan40pxToScrollStart = (nextStep) => {
  const scrollLeftAfterOneClick = carousel.scrollLeft - nextStep;
  return scrollLeftAfterOneClick < 40;
}
const handleClickGoAhead = () => {
  let nextStep = carousel.offsetWidth;
  if (willLeftLessThan40pxToScrollEnd(nextStep)) nextStep *= 2;

  carousel.scroll({
    left: carousel.scrollLeft + nextStep,
    behavior: "smooth"
  });
}
const handleClickGoBack = () => {
  let nextStep = carousel.offsetWidth;
  if (willLeftLessThan40pxToScrollStart(nextStep)) nextStep *= 2;

  carousel.scroll({
    left: carousel.scrollLeft - nextStep,
    behavior: "smooth"
  });
}
/*---------home slider--------*/
document.addEventListener('DOMContentLoaded', function () {
  var swiper = new Swiper('.swiper-container', {
    loop: true,
    effect: 'fade',
    speed: 1000,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false,
    },
  });
});





$(document).ready(function () {
  $('.owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    responsive: {
      0: {
        items: 1
      },
      600: {
        items: 3
      },
      1000: {
        items: 5
      }
    }
  });
});

$(document).ready(function() {
    const progressFill = document.querySelector(".progress-fill");
    var swiper = new Swiper(".parallax-slider", {
        speed: 1000,
        parallax: true,
        loop: true,
        autoplay: {
            delay: 10000, // Adjust autoplay delay as needed
            disableOnInteraction: false
        },
        grabCursor: true,
        effect: "creative",
        creativeEffect: {
            prev: {
                shadow: true,
                translate: [0, 0, -1000]
            },
            next: {
                translate: ["100%", 0, 0]
            }
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        },
        on: {
            slideChange: function () {
                // Reset progress bar when slide changes
                progressFill.style.width = '0%';
            },
            autoplayTimeLeft(s, time, progress) {
                // Update progress bar width based on autoplay time left
                progressFill.style.width = (1 - progress) * 100 + '%';
            }
        }
    });
});

/*Carrousel Premium */
$(document).ready(function() {
  const progressFill = document.querySelector(".progress-fill");
  var swiper = new Swiper(".parallax-slider", {
      speed: 1000,
      parallax: true,
      loop: true,
      autoplay: {
          delay: 10000, // Adjust autoplay delay as needed
          disableOnInteraction: false
      },
      grabCursor: true,
      effect: "creative",
      creativeEffect: {
          prev: {
              shadow: true,
              translate: [0, 0, -1000]
          },
          next: {
              translate: ["100%", 0, 0]
          }
      },
      pagination: {
          el: ".swiper-pagination",
          clickable: true
      },
      navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev"
      },
      on: {
          slideChange: function () {
              // Reset progress bar when slide changes
              progressFill.style.width = '0%';
          },
          autoplayTimeLeft(s, time, progress) {
              // Update progress bar width based on autoplay time left
              progressFill.style.width = (1 - progress) * 100 + '%';
          }
      }
  });
});